import './app.css'
import { Main } from './components/main';

export function App() {
  return (
    <>
      <div>
        <Main />
      </div>
    </>
  );
}
