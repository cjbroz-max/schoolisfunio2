import tailwindcss from 'tailwindcss';

export default {
  plugins: [
    tailwindcss
  ]
};