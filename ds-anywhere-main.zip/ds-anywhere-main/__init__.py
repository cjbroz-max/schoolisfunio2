# This file exists to allow scripts to use import syntax like:
#
# import scripts.common.output as output
#
# Rather than having to use "import common.output" or "import output"