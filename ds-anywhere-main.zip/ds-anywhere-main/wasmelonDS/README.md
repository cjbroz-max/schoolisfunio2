# melonDS

Many of the files here are forked from [melonDS](https://github.com/melonDS-emu/melonDS/tree/master). Most of the logic specific
to the WebAssembly frontend is located in `src/frontend/wasm`.