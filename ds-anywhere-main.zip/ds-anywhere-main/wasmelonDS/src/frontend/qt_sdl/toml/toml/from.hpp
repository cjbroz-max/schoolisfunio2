//     Copyright Toru Niina 2019.
// Distributed under the MIT License.
#ifndef TOML11_FROM_HPP
#define TOML11_FROM_HPP

namespace toml
{

template<typename T>
struct from;
// {
//     static T from_toml(const toml::value& v)
//     {
//         // User-defined conversions ...
//     }
// };

} // toml
#endif // TOML11_FROM_HPP
