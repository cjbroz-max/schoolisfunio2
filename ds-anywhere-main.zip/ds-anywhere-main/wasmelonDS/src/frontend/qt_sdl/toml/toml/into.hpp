//     Copyright Toru Niina 2019.
// Distributed under the MIT License.
#ifndef TOML11_INTO_HPP
#define TOML11_INTO_HPP

namespace toml
{

template<typename T>
struct into;
// {
//     static toml::value into_toml(const T& user_defined_type)
//     {
//         // User-defined conversions ...
//     }
// };

} // toml
#endif // TOML11_INTO_HPP
